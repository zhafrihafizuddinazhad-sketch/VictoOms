<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('orders', function (Blueprint $table) {

        $table->longText('customer_brief')
              ->nullable()
              ->after('remarks');

    });
}

public function down(): void
{
    Schema::table('orders', function (Blueprint $table) {

        $table->dropColumn('customer_brief');

    });
}
};
