<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('product_photos', function (Blueprint $table) {

        $table->id();

        $table->foreignId('order_id')
            ->constrained()
            ->cascadeOnDelete();

        $table->foreignId('uploaded_by')
            ->constrained('users')
            ->cascadeOnDelete();

        $table->string('photo_name');

        $table->string('photo_path');

        $table->text('remarks')->nullable();

        $table->timestamps();

    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_photos');
    }
};
